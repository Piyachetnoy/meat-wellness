# detect_steak > 2023-01-04 9:03pm
https://universe.roboflow.com/kangwon-national-university-uqfeh/detect_steak

Provided by a Roboflow user
License: CC BY 4.0

